// Safe example adapter. Replace with a retailer's authorized API implementation.
module.exports={name:'example-connector',async search(profile){return []}};
