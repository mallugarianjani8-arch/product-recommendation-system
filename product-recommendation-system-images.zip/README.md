# Personalized Product Recommendation System

Profile-driven product discovery app with image cards. Users enter name, age, interests, optional budget and category. Includes sample laptop, headphones, skincare and other items with images so it works immediately.

## Run
1. Install Node.js 18+.
2. In `backend`, run `npm install`.
3. Copy `.env.example` to `.env`; configure Supabase if desired.
4. Run `npm run dev` in `backend`.
5. Open `frontend/index.html`, fill profile, and click Find my products.
6. To use Supabase, run `supabase/schema.sql` in its SQL Editor.

A budget of 0 means no maximum. The sample catalog works without Supabase. For real products from ecommerce sites, each store must authorize its API or product feed. Add adapter files in `backend/connectors` and put API keys only in backend `.env`. See connector README. Sample images are remote image URLs.
